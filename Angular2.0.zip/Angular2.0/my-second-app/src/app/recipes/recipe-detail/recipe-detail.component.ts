import { Component, OnInit, Input } from '@angular/core';
import { Recipe } from '../recipe.model';
import { RecipeListService } from 'src/app/services/recipeList.service';
import { RecipeService } from '../recipe.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-recipe-detail',
  templateUrl: './recipe-detail.component.html',
  styleUrls: ['./recipe-detail.component.css']
})
export class RecipeDetailComponent implements OnInit {


  // need selected recipe detail
  @Input() recipe: Recipe

  id: number;

  constructor(private recipeListService: RecipeListService,
    private recipeService: RecipeService,
    private route: ActivatedRoute,
    private router: Router) {
    // Cross Component communication using services 
    this.recipeListService.statusUpdated.subscribe(
      (status: string) => console.log("======Recipe recived with name================" + status)
    );

  }

  ngOnInit() {
    // getting route parameter if id will not change
    // const id = this.route.snapshot.params["name"]

    // getting route parameter if id will  keep on changing
    this.route.params.subscribe(
      (param: Params) => {
        // by adding + converting string to number
        this.id = +param["id"]

        this.recipe = this.recipeService.getRecipesById(this.id);
      }

    );

  }

  onAddedToShoppingList() {
    this.recipeService.addIngredientToShoppingList(this.recipe.ingredient);
  }

  onEditRecipe() {
    this.router.navigate(['../', this.id, 'edit'], { relativeTo: this.route });
  }

  onDeleleRecipe(){

    this.recipeService.deleteRecipe(this.id)
    this.router.navigate(['/recipes'])
  }

}
