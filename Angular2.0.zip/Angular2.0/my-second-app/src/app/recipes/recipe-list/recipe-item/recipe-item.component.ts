import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Recipe } from '../../recipe.model';
import { RecipeListService } from 'src/app/services/recipeList.service';
import { RecipeService } from '../../recipe.service';

@Component({
  selector: 'app-recipe-item',
  templateUrl: './recipe-item.component.html',
  styleUrls: ['./recipe-item.component.css']
})
export class RecipeItemComponent implements OnInit {

  @Input() recipe:Recipe;

  @Input() index:number;

    // Approch 1
  //@Output() recipeSelected = new EventEmitter<void>();

  
    // approach 2
    constructor(private recipeService:RecipeService){}


  ngOnInit() {
  }


  onSelected(){
    // approach 1
   // this.recipeSelected.emit();

    // approach 2
       this.recipeService.recipeSelected.emit(this.recipe);
 
  }

}
