import { Recipe } from './recipe.model';
import { EventEmitter, Injectable } from '@angular/core';
import { Ingredient } from '../shared/ingredient.model';
import { ShoppingListService } from '../shopping-list/shopping-list.service';
import { Subject } from 'rxjs';

@Injectable()
export class RecipeService {
    // Approch 2
    recipeSelected = new EventEmitter<Recipe>();

    recipeChange = new Subject<Recipe[]>();


    constructor(private shoppingListService:ShoppingListService){}

    private recipes: Recipe[] = [
        new Recipe("Test Recipe1","Description for test recipe1","https://upload.wikimedia.org/wikipedia/commons/7/72/Schnitzel.JPG",[
            new Ingredient('Meat',1),
            new Ingredient('French',20)

        ])
        ,new Recipe("Test Recipe2","Description for test recipe2","Image2",[
            new Ingredient('Buns',1),
            new Ingredient('cold Drink',1)
        ])
       ];

    getRecipes(){
        return this.recipes.slice();
    }


    addIngredientToShoppingList(ingredient:Ingredient[]){
               console.log("========addIngredientToShoppingList======")
               console.log(ingredient)
       this.shoppingListService.addIngredientToShopping(ingredient);
             
    }


    getRecipesById(index:number){
      return this.recipes.slice()[index];
    }

    addRecipe(recipe: Recipe){

     this.recipes.push(recipe)
     this.recipeChange.next(this.recipes.slice());
    }

    updateRecipe(index:number, recipe:Recipe){
        this.recipes[index] = recipe;
        this.recipeChange.next(this.recipes.slice());
    }


    deleteRecipe(index:number){
        this.recipes.splice(index,1)
        this.recipeChange.next(this.recipes.slice());

    }

}