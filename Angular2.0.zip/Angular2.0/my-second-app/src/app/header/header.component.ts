import { Component, EventEmitter, Output } from '@angular/core';
import { resolve } from 'url';



// decorator
@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})
export class HeaderComponent {

    todayDate: Date

    @Output() featureSelected = new EventEmitter<string>();
    constructor(){
        console.log("=======HeaderComponent====") 

        this.todayDate = new Date(18,12,2018);
     }

     onSelect(feature: string){
          this.featureSelected.emit(feature);
     }

     appStatus = new Promise((resolve,reject) => {
        setTimeout(()=>{
            resolve("Up");
        },2000)

     });
}