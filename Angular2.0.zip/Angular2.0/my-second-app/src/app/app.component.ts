import { Component, OnInit, OnDestroy } from '@angular/core';

import {LoggingService} from "./services/logging.service";
import { Observable, Observer, Subscription } from 'rxjs';
import { EmployeeService } from './employee.service';
import { error } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // adding service dependency injection
 // providers:[LoggingService]
})
export class AppComponent implements OnInit ,OnDestroy {


  myCustomObserables: Subscription;

 // adding service dependency
  constructor(private loggingService:LoggingService,private employeeService:EmployeeService){}

  title = 'my-second-app';
  
  loadedFeature='recipe';


  ngOnInit(){

      // writing custom obderables
  const myObserables = Observable.create((observer:Observer<string>) =>{
    setTimeout(() =>{
      observer.next("First Data packet")
    },1000);

    setTimeout(() =>{
      observer.next("Second Data packet")
    },2000);

    setTimeout(() =>{
      observer.error("there is an error")
    },5000);

    setTimeout(() =>{
      observer.complete();
    },6000);

});

     this.myCustomObserables= myObserables.subscribe(

        (data:string) => {console.log(data)},
        (error:string) => {console.log(error)},
        () => {console.log("completed")}
      );


  }

  onNavigate(selectedFeature:string){
     this.loadedFeature = selectedFeature;
     this.loggingService.logCurrentStatus(selectedFeature);
  }

  onlyOdd:boolean = false;

  value:number = 3;


  employeeInfo(){
    this.employeeService.getEmployee().subscribe(
    //  (response:Response) => {
    //    const data = response.json();
     //   console.log(data)
     // } ,
     (data:any) =>{
      console.log(data)
     },
      (error) => console.log("Error message "+error)
    )
  }

  addEmployee(){
    const data = {empId:3, name:'Associate Software', designation: "anil", salary: 1000};
    this.employeeService.addEmployee(data);

  }

  ngOnDestroy(){
      this.myCustomObserables.unsubscribe();
  }



}
