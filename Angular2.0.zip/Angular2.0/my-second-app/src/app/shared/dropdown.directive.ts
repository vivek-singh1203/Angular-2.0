import {Directive, HostListener, Host, HostBinding} from '@angular/core';
import {LoggingService} from "../services/logging.service";


@Directive({
   selector:'[appDropdown]',
   // which instance we want to use whether we will be using instance from  parent component or whether we want 
    // to used child component instance.
  // providers:[LoggingService]
})
export class DropDownDirective{

    // We have added loggingService dependency
constructor(private loggingService: LoggingService){}

    // property binding to the element where directive is placed on.
    @HostBinding('class.open') isOpen = false;

     isDowndown:string = "Closed";
    
    @HostListener('click') toggleOpen(){

      this.isOpen = !this.isOpen;

      if(this.isOpen){
        this.isDowndown= "Open";
      }
      this.loggingService.logCurrentStatus(this.isDowndown);
    }

}