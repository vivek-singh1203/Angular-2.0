import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
// add the newly created component file with extension
import { HeaderComponent} from './header/header.component';
import { RecipesComponent } from './recipes/recipes.component';
import { RecipeListComponent } from './recipes/recipe-list/recipe-list.component';
import { RecipeDetailComponent } from './recipes/recipe-detail/recipe-detail.component';
import { RecipeItemComponent } from './recipes/recipe-list/recipe-item/recipe-item.component';
import { ShoppingListComponent } from './shopping-list/shopping-list.component';
import { ShoppingEditComponent } from './shopping-list/shopping-edit/shopping-edit.component';
import { BasicHighlightDirective } from './directives/highlight.directives';
import { BetterHighLightDirective } from './directives/betterHighlighterDriective';
import { CustomStructureDirective } from './directives/customStructuralDirective';
import { DropDownDirective } from './shared/dropdown.directive';
import { LoggingService } from './services/logging.service';
import { DataService } from './services/data.service';
import { RecipeDetailService } from './services/recipeDetail.service';
import { RecipeListService } from './services/recipeList.service';
import { ShoppingListService } from './shopping-list/shopping-list.service';
import { AppRoutingModule } from './app-routing.module';
import { RecipeStartComponent } from './recipes/recipe-start/recipe-start.component';
import { RecipeEditComponent } from './recipes/recipe-edit/recipe-edit.component';
import { ShortenPipe } from './header/shorten.pipe';
import { HttpClientModule } from '@angular/common/http';
import { EmployeeService } from './employee.service';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    RecipesComponent,
    RecipeListComponent,
    RecipeDetailComponent,
    RecipeItemComponent,
    ShoppingListComponent,
    ShoppingEditComponent,
    // we need to declare the directives
    BasicHighlightDirective,
    BetterHighLightDirective,
    CustomStructureDirective,
    DropDownDirective,
    RecipeStartComponent,
    RecipeEditComponent,
    ShortenPipe

  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule, // need to be added for syncroning html code 
    AppRoutingModule,
    HttpClientModule

  ],
  // dependency added here is aviliable through out application.
  providers:[LoggingService,DataService,RecipeListService,RecipeDetailService,ShoppingListService,EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
