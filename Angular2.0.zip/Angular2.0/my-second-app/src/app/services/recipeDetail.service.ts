export class RecipeDetailService{
     showRecipeDetail(){
         
     }
}