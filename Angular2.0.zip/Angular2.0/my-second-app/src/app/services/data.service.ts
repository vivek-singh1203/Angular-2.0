export class DataService {
    addData(message:string){
          console.log("print the provided message "+message)
    }
}