import { DataService } from './data.service';
import { Injectable } from '@angular/core';

@Injectable()
export class LoggingService{

constructor(private dataService: DataService){}

    logCurrentStatus(status:string){
        console.log(" Log status in service "+status);

        this.dataService.addData("Service injected")
    }
}