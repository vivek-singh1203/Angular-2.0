import { EventEmitter } from '@angular/core';

export class RecipeListService{

    statusUpdated = new EventEmitter<string>();

}