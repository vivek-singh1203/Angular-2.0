import { Directive, OnInit, ElementRef, Renderer2, HostListener, HostBinding, Input } from '@angular/core';

@Directive({
    selector:'[appBetterHighlight]'
})
export class BetterHighLightDirective implements OnInit {

  @Input() defaultColor:string = 'transparent' ;
  @Input() highlightColor:string = 'blue' ;

   // @HostBinding('style.backgroundColor') backgroundColor:string = this.defaultColor;
    @HostBinding('style.backgroundColor') backgroundColor:string;

    constructor(private elmentRef:ElementRef, private renderer:Renderer2){
     
    }

    

    ngOnInit(){
        this.backgroundColor = this.defaultColor;
      //  this.renderer.setStyle(this.elmentRef.nativeElement,'background-color','Green')
    }

    @HostListener('mouseenter') mouseenter(eventData:Event){
       // this.renderer.setStyle(this.elmentRef.nativeElement,'background-color','Green');
       this.backgroundColor = this.highlightColor;    
    }

    @HostListener('mouseleave') mouseleave(eventData:Event){
       // this.renderer.setStyle(this.elmentRef.nativeElement,'background-color','red');
       this.backgroundColor = this.defaultColor;    
    }
    
}