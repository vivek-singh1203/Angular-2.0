import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import 'rxjs/Rx';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/catch';




@Injectable()
export class EmployeeService {
   constructor(private http:HttpClient){}


   getEmployee(){
    

      const httpOptions = {
        headers: new HttpHeaders({
          'Content-Type':  'application/json',
          //'Authorization': 'my-auth-token',
          'Access-Control-Allow-Origin':'http://localhost:8080/employee'
        })

    }
  // return this.http.get('http://localhost:8080/employee')
      // transform response easily using Observable operator map()
    return this.http.get('http://localhost:8080/employees').map(
        (response:Response) =>{
            //console.log(response)
             //const data = response.json()
            // console.log("========================")
             //console.log(data)
             return response;
          }
     )  .catch(
        (error: Response) => {
          return Observable.throw('Something went wrong');
        }
      );
    
}


addEmployee(employee:any){

    const headers = new HttpHeaders({'Content-Type': 'application/json'});
     return this.http.post('https://udemy-ng-http.firebaseio.com/data.json',employee,{headers: headers});
}
}