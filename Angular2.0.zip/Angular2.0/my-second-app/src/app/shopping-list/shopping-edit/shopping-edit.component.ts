import { Component, OnInit, ViewChild, ElementRef, EventEmitter, Output, OnDestroy } from '@angular/core';
import { Ingredient } from 'src/app/shared/ingredient.model';
import { ShoppingListService } from '../shopping-list.service';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-shopping-edit',
  templateUrl: './shopping-edit.component.html',
  styleUrls: ['./shopping-edit.component.css']
})
export class ShoppingEditComponent implements OnInit ,OnDestroy {

  subscription: Subscription
  editMode:boolean = false;
  itemEditedIndex;
  editedIngredient:Ingredient;

  @ViewChild("f") slForm:NgForm;

  constructor(private shoppingListService:ShoppingListService) { }

  @ViewChild("nameInput") name:ElementRef
  @ViewChild("amountInput") amount:ElementRef

  @Output() ingredientAdded = new EventEmitter<Ingredient>();

  ngOnInit() {

    this.subscription = this.shoppingListService.startEditing.subscribe(

     (index:number) =>{
       console.log(index)
       this.editMode =true;
       this.itemEditedIndex = index;
       this.editedIngredient = this.shoppingListService.getIngredientByIndex(index);

       this.slForm.setValue ({
              name:this.editedIngredient.name,
              amount:this.editedIngredient.amount,
       })

     }

    )
  }

  onFormSubmit(){
   //console.log(this.name.nativeElement.textContentme);
   //new Ingredient(this.name.nativeElement.textContentme,this.amount.nativeElement.textContentme);
   const newIngredient = new Ingredient(this.name.nativeElement.value,this.amount.nativeElement.value)
   // Approach 1
   //this.ingredientAdded.emit(newIngredient);

 // Approach 2
    this.shoppingListService.addedIngredient(newIngredient);

  }


  onAddItem(form:NgForm){
    const newIngredient = new Ingredient(form.value.name,form.value.amount)
if(this.editMode){
  this.shoppingListService.updateIngredient(this.itemEditedIndex,newIngredient);
}else{
  this.shoppingListService.addedIngredient(newIngredient);
}
form.reset();

  }


  clearForm(){

    this.slForm.reset();
    this.editMode=false;
  }


  onDelete(){
    this.shoppingListService.deleteIngredient(this.itemEditedIndex)
     this.clearForm()
  }

  ngOnDestroy(){
    this.subscription.unsubscribe();
  }

}
