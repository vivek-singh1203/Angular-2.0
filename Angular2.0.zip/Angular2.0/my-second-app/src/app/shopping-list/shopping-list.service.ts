import { Ingredient } from '../shared/ingredient.model';
import { EventEmitter } from '@angular/core';
import { Subject } from 'rxjs';

export class ShoppingListService {
    
    //ingredientChanged =  new EventEmitter<Ingredient[]>();
    // We are replacing eventEmitter with subject
    ingredientChanged =  new Subject<Ingredient[]>();

    startEditing = new Subject<number>();

    private ingredients: Ingredient[] = [
        new Ingredient("Apple" ,5),
        new Ingredient("Tamatos" ,10)
   ];


    getIngredient(){
        // retuning copy of ingredient
    return this.ingredients.slice();
    }

    getIngredientByIndex(index:number){
        // retuning copy of ingredient
      return this.ingredients[index];
    }



    addedIngredient(ingredient :Ingredient){
       this.ingredients.push(ingredient);
      // We are replacing eventEmitter with subject
      // this.ingredientChanged.emit(this.ingredients.slice());
       
         this.ingredientChanged.next(this.ingredients.slice());
    }

    updateIngredient(editedIndex:number, newIngredient: Ingredient){
        this.ingredients[editedIndex] = newIngredient;

        this.ingredientChanged.next(this.ingredients.slice());
    }


    deleteIngredient(index:number){
        this.ingredients.splice(index,1);
        this.ingredientChanged.next(this.ingredients.slice());
    }


    addIngredientToShopping(ingredient :Ingredient[]){
        this.ingredients.push(...ingredient);

         // We are replacing eventEmitter with subject
        //this.ingredientChanged.emit(this.ingredients.slice());
        this.ingredientChanged.next(this.ingredients.slice());
    }

}