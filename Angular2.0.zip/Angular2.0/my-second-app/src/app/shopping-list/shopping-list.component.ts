import { Component, OnInit, OnDestroy } from '@angular/core';
import { Ingredient } from '../shared/ingredient.model';
import { ShoppingListService } from './shopping-list.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-shopping-list',
  templateUrl: './shopping-list.component.html',
  styleUrls: ['./shopping-list.component.css']
})
export class ShoppingListComponent implements OnInit ,OnDestroy{

  ingredients: Ingredient[] = [];

  private subscription:Subscription;

  // Approach1
/*   ingredients: Ingredient[] = [
       new Ingredient("Apple" ,5),
       new Ingredient("Tamatos" ,10)

  ]; */

  constructor(private shoppingListService: ShoppingListService) { }

  ngOnInit() {
    // all heaving lifting initialized needs to be done here.
    this.ingredients = this.shoppingListService.getIngredient();


    this.subscription = this.shoppingListService.ingredientChanged.subscribe(

           (ingredients: Ingredient[] ) => {

            console.log("ShoppingListComponent")
            console.log(ingredients)
            this.ingredients = ingredients;
           }

    )

  }

  // Approach1
 /*  addedIngredient(ingredient :Ingredient){
    this.ingredients.push(ingredient);
  } */


  onEditItem(i:number){
    this.shoppingListService.startEditing.next(i);
  }


 ngOnDestroy(){
    this.subscription.unsubscribe();
 }
 

}
