import { Component } from '@angular/core';

@Component({
  // elements selector
  selector: 'app-root',
  templateUrl: './app.component.html',
  //styleUrls: ['./app.component.css'] // external template
  // inline styles
  styles: [`
    h3 {
      color:green
    }
  `]
})
export class AppComponent {
 
}
