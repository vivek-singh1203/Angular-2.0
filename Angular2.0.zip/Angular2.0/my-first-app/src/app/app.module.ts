import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
// Add import here
import { ServerComponent } from './server/server.component';
import { ServersComponent } from './servers/servers.component';

@NgModule({
  declarations: [
    AppComponent,
    // we regsiter new components here
    ServerComponent,
    ServersComponent
  ],
  // allow to add other modules to appModule
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  // list of all the Component which should be know to augular at the time of analysis angular index.html page
  bootstrap: [AppComponent]
})
export class AppModule { }
