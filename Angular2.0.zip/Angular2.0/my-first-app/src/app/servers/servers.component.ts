import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  
  // attribute selector
  //selector: '[app-servers]',
 // elements selector
  selector: 'app-servers',
   // class selector
  //selector: '.app-servers',
  // link to external template file
  templateUrl: './servers.component.html',
 // template:'<app-server></app-server><hr><app-server></app-server>', // using unline template
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit , OnChanges{

   allowNewServer: boolean = false;

   serverCreateStatus = 'No Server created';

   serverName='Test Server';

   serverCreated = false;

   servers = ['Test server','Stagging Server'];


   // just a build in method each typescript class has, call once when components is created
  constructor() { 
    console.log("====constuctor invoke====")
    
    setTimeout( () => {
      this.allowNewServer =true;
    },2000);

  }

  ngOnInit() {

    console.log("====ngOnInit invoke====")
  }
  
  ngOnChanges(change:SimpleChanges){
    console.log("====ngOnChanges invoke====")
    console.log(change)
    console.log(change)

  }

  onCreateServer(){
    this.serverCreated = true;

    this.servers.push('Production Server')
    this.serverCreateStatus = 'Server created with name:: '+this.serverName;
  }

  onServerNameUpdate(event:Event){
    console.log(event)
    this.serverName = (<HTMLInputElement>event.target).value;
  }

}
