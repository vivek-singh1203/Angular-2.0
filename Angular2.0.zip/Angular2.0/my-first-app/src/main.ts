import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
}

// first code to execute and this launch our angular application by passsing app module
  // and appMOdule refer to app.module.ts file
platformBrowserDynamic().bootstrapModule(AppModule)
  .catch(err => console.error(err));
