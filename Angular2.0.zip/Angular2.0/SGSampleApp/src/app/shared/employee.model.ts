export class Employee {

    constructor(public firstName: string, public lastName: string,
        public dateOfBirth: string, public gender: string, public department: string) { }
}