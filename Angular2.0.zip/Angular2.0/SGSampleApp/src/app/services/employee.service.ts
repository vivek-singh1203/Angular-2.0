import { Employee } from '../shared/employee.model';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/Rx';
import { map, catchError } from 'rxjs/operators';
import { Observable } from 'rxjs';



@Injectable()
export class EmployeeService {

    constructor(private http: HttpClient) { }



    getEmployee() {

        return this.http.get('http://localhost:8090/employee/all').map(
            (response: Response) => {
                return response;
            }
        ).catch(
            (error: Response) => {
                return Observable.throw('Something went wrong');
            }
        );

    }


    addEmployee(employee: Employee): Observable<Employee> {
        console.log("Services is getting invoke")
        console.log(employee)

        const httpOptions = {
            headers: new HttpHeaders({
                'Content-Type': 'application/json',
                'Authorization': 'my-auth-token'
            })
        };
        return this.http.post<Employee>('http://localhost:8090/employee/add', employee, httpOptions);

    }



}