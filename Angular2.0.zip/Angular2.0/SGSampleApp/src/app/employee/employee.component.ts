import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Employee } from '../shared/employee.model';
import { EmployeeService } from '../services/employee.service';

@Component({
    selector: 'employee',
    templateUrl: './employee.component.html',
    styleUrls: ['./employee.component.css'],
    providers:[EmployeeService]
})
export class EmployeeComponent implements OnInit {


    employees: Employee[] = [];
    constructor(private employeeService: EmployeeService) { }

    @ViewChild("f") slForm: NgForm;

    ngOnInit() {


        this.employeeService.getEmployee().subscribe(
            (data: any) => {
                this.employees = data;
                console.log(this.employees)
            },
            (error) => console.log("Error message " + error)
        )
    }


    employeeInfo() {

    }



    onAddItem(form: NgForm) {
        const newEmployee = new Employee(form.value.firstName, form.value.lastName,
            form.value.dateOfBirth, form.value.gender, form.value.department)

        this.employeeService.addEmployee(newEmployee).subscribe(employee => {


            this.employees.push(employee)

            console.log(employee);


        });

        form.reset();

    }


    clearForm() {
        this.slForm.reset();
    }

}